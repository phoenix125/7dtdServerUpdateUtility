7dtdServerUtility - A Utility To Keep Your 7 days To Die Dedicated Server updated (and schedule server restarts, download and install new server files, and more!)
- Latest version: 7dtdServerUtility_v1.0 (2018-12-16)
- By Phoenix125 | http://www.Phoenix125.com | Based on Dateranoth's ConanExilesServerUtility-3.2.3 and ServerUtility

-----------------
 GETTING STARTED (Two sets of instructions: one for existing servers and the other to use the 7dtdServerUtility tol to download and install the dedicated server)
-----------------

EXISTING SERVER:
1) Run 7dtdServerUtility.exe
- It will create the config file, 7dtdServerUtility.ini, then exit.
2) Modify the 7dtdServerUtility.ini file to match your server's config and install folder and any other desired features.
3) Run 7dtdServerUtility.exe again.
- It will validate your files and install any updates
4) Your server should be up-to-date and running! 

FRESH SERVER: Use 7dtdServerUtility to download install a fresh dedicaed server
1) Run 7dtdServerUtility.exe
- It will create the config file, 7dtdServerUtility.ini
2) Open the 7dtdServerUtility.ini with Notepad and adjust the follow parameters:
+ "Serverdir=" 	[Enter your desired server fodler]
+ "steamcmddir="   [Entere desired SteamCMD folder] (SteamCMD is Steam's utility to download and install the Steam programs)
+ "[Version: 0-Stable/1-Latest Experimental] ServerVer=0" [Select Stable or Experimental version]
- No need to make any other changes at this time.
3) Run 7dtdServerUtility.exe again.
- All the required files will be downloaded and installed.
- Once completed, your server will be running... Now it's time to config the server and utility.
4) Shut down the server by rt-clicking on the 7dtdServerUtility icon on the lower right.
5) Modify the remainder of te settings in the 7dtdServerUtility.ini file.
6) Modify the serverconfig.xml within the 7DTD server folder.
7) Run 7dtdServerUtility.exe again.
8) Congrats! Your new server is running.

--------------
 INSTRUCTIONS
-------------- 
(Note: It is suggested that you RENAME or COPY the default serverconfig.xml file as it will be overwritten with any updates)

To Shutdown your server:
- Right-click on the 7dtdServerUtility icon and select EXIT.
To restart your server:
- Run 7dtdServerUtility.exe

----------
 FEATURES
----------
- Automatically download and install a new 7 Days To Die Dedicated Server: No need to do it manually.
- Automatically keeps server updated.
- Announce server updates and restarts on Discord, Twitch, and MCRCON.
- Works with both STABLE and EXPERIMENTAL versions
- KeepServerAlive: Detects server crashes and will restart the server.
- User-defined scheduled reboots
- Remote restart (via web browser)
- Clean shutdown of yoru server.
- Retain detailed logs of 7DTD dedicated server and 7dtdServerUtility.

------------------
 PLANNED FEATURES
------------------
To be implemented by end of 2018
- Automatically import server settings from serverconfig.xml (or user defined file)
- The option to backup old save & serverconfig.xml and wipe server with each update
- The option to automatically add build number to server name after updates (so that users can quickly identify that you are running the latest server)
- Post source files to Github

---------
 CREDITS
---------
- Based on Dateranoth's ConanExilesServerUtility-3.2.3 and ServerUtility (He wrote MOST of the code used in this program.. THANK YOU!)
https://gamercide.org/forum/topic/9296-7-days-to-die-server-utility/
https://gamercide.org/forum/topic/10558-conan-exiles-server-utility/

----------------
 DOWNLOAD LINKS
----------------
Latest Version: 	http://www.phoenix125.com/share/7dtdServerUtility.zip
Source Code (AutoIT): 	http://www.phoenix125.com/share/7dtdServerUtility.au3

Visit http://www.Phoenix125.com for more info.